function saludar(){

    let numA = document.getElementById('valorA').value;
    let numB = document.getElementById('valorB').value;
    let resultado = parseInt(numA) + parseInt(numB);

    console.log(saludar);
    console.log(resultado);
}

